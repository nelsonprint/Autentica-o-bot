print("========================")
print("RECEBE SINAIS TELEGRAM")
print("========================")

from telethon import TelegramClient, events
import asyncio
import sqlite3
from datetime import datetime

# Substitua com suas credenciais
api_id = '23147867'
api_hash = '4de4d409756a2b8c38f154ccc629d8c3'
phone_number = '+5554981125628'

# Conecte-se ao banco de dados SQLite
conn = sqlite3.connect('ordens.db')
cursor = conn.cursor()

# Função para criar a tabela 'sinais' se não existir
def criar_banco_de_dados():
    cursor.execute('''CREATE TABLE IF NOT EXISTS sinais (
                        Hora TEXT,
                        Ativo TEXT,
                        Timer INTEGER,
                        Direcao TEXT,
                        Valor REAL,
                        Status TEXT DEFAULT '0')''')  # Adiciona a coluna 'Status' com valor padrão 'x'
    conn.commit()

criar_banco_de_dados()  # Chama a função para garantir que a tabela esteja criada corretamente

async def main():
    # Inicialize o cliente Telegram
    client = TelegramClient('session_name', api_id, api_hash)
    await client.start(phone_number)
    print("Conectado!")

    # Substitua pelo ID do canal de origem
    channel_id_origem = -1001532323810 #-1002172618076  # ID do canal

    try:
        # Resolva o ID do canal
        entity = await client.get_entity(channel_id_origem)
    except ValueError as e:
        print(f"Erro ao resolver o ID do canal: {e}")
        return

    @client.on(events.NewMessage(chats=entity))
    async def handler(event):
        try:
            message = event.message
            if message.text:
                ultima_mensagem = message.text
                print(f"Nova mensagem recebida: {ultima_mensagem}")

                linhas = ultima_mensagem.split('\n')
                i = 0  # Adicionado para definir o início da iteração

                while i < len(linhas):
                    if "⚡️ATIVO: " in linhas[i] and not linhas[i].startswith("🔥"):
                        ativo = linhas[i].replace("⚡️ATIVO: ", "").strip()
                        ativo = ativo.replace("(OTC-IQ)", "").strip()  # Remove "(OTC-IQ)" do ativo
                        
                        if i + 1 < len(linhas) and "⚡️HORÁRIO: " in linhas[i + 1]:
                            horario_str = linhas[i + 1].replace("⚡️HORÁRIO: ", "").strip()
                            if ":" in horario_str:  # Verifica se horario_str possui o formato de hora esperado
                                horario = datetime.strptime(horario_str, "%H:%M").strftime("%H:%M")
                                if i + 2 < len(linhas) and "⚡️DIREÇÃO: " in linhas[i + 2]:
                                    direcao = linhas[i + 2].replace("⚡️DIREÇÃO: ", "").strip().upper()
                                    sentido = direcao.split("(")[0].strip()  # Obtém a direção sem o time
                                    tempo = direcao.split("(")[1].strip(")M")

                                    sinal_formatado = f"{horario} {ativo} {tempo} {sentido} 5.0"

                                    # Verifica se o sinal já existe no banco de dados
                                    cursor.execute("SELECT * FROM sinais WHERE Hora = ? AND Ativo = ? AND Direcao = ?", (horario, ativo, sentido))
                                    data = cursor.fetchone()
                                    if data is None:
                                        cursor.execute("INSERT INTO sinais (Hora, Ativo, Timer, Direcao, Valor, Status) VALUES (?, ?, ?, ?, ?, ?)",
                                                       (horario, ativo, tempo, sentido, 5.0, '0'))
                                        conn.commit()
                                        print(f"Sinal processado e inserido: {sinal_formatado}")
                                else:
                                    print(f"Formato de direção inválido encontrado: {direcao}")
                            else:
                                print(f"Formato de hora inválido encontrado: {horario_str}")

                    i += 1  # Incremento do índice

        except Exception as e:
            print(f"Erro ao processar mensagem: {e}")

    print("Aguardando novas mensagens...")

    try:
        await client.run_until_disconnected()
    except (KeyboardInterrupt, SystemExit):
        print("Script interrompido.")
    except Exception as e:
        print(f"Ocorreu um erro inesperado: {e}")
    finally:
        # Feche a conexão com o banco de dados ao final do script
        conn.close()

if __name__ == '__main__':
    asyncio.run(main())
