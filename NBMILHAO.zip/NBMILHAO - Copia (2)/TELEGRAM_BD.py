print("========================")
print("RECEBE SINAIS TELEGRAM")
print("========================")

from telethon import TelegramClient, events
import asyncio
import sqlite3
from datetime import datetime

# Substitua com suas credenciais
api_id = '23147867'
api_hash = '4de4d409756a2b8c38f154ccc629d8c3'
phone_number = '+5554981125628'

# Função para criar a tabela 'sinais' se não existir
def criar_banco_de_dados():
    conn = sqlite3.connect('ordens.db')
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS sinais (
                        Hora TEXT,
                        Ativo TEXT,
                        Timer INTEGER,
                        Direcao TEXT,
                        Valor REAL,
                        Status TEXT DEFAULT '0')''')  # Corrigido o valor padrão de Status
    conn.commit()
    conn.close()

criar_banco_de_dados()  # Chama a função para garantir que a tabela esteja criada corretamente

async def main():
    # Inicialize o cliente Telegram
    client = TelegramClient('session_name', api_id, api_hash)
    await client.start(phone_number)
    print("Conectado!")

    # Substitua pelo ID do canal de origem
    channel_id_origem = -1002172618076

    try:
        # Resolva o ID do canal
        entity = await client.get_entity(channel_id_origem)
    except ValueError as e:
        print(f"Erro ao resolver o ID do canal: {e}")
        return

    @client.on(events.NewMessage(chats=entity))
    async def handler(event):
        try:
            conn = sqlite3.connect('ordens.db')
            cursor = conn.cursor()
            
            message = event.message
            if message.text:
                ultima_mensagem = message.text
                print(f"Nova mensagem recebida: {ultima_mensagem}")

                linhas = ultima_mensagem.split('\n')

                i = 0
                while i < len(linhas):
                    if "⚡️ATIVO:" in linhas[i]:
                        # Formato detalhado com ⚡️
                        ativo = linhas[i].replace("⚡️ATIVO:", "").strip()
                        i += 1
                        if i < len(linhas) and "⚡️HORÁRIO:" in linhas[i]:
                            horario_str = linhas[i].replace("⚡️HORÁRIO:", "").strip()
                            i += 1
                            if i < len(linhas) and "⚡️DIREÇÃO:" in linhas[i]:
                                direcao = linhas[i].replace("⚡️DIREÇÃO:", "").strip()
                                if ":" in horario_str:  # Verifica se horario_str possui o formato de hora esperado
                                    horario = datetime.strptime(horario_str, "%H:%M").strftime("%H:%M")
                                    sentido = direcao.split('(')[0].strip().upper()  # Remove o texto "(M5)" e transforma em maiúsculas

                                    sinal_formatado = f"{horario} {ativo} 5 {sentido} 5.0"

                                    # Verifica se o sinal já existe no banco de dados
                                    cursor.execute("SELECT * FROM sinais WHERE Hora = ? AND Ativo = ? AND Direcao = ?", (horario, ativo, sentido))
                                    data = cursor.fetchone()
                                    if data is None:
                                        cursor.execute("INSERT INTO sinais (Hora, Ativo, Timer, Direcao, Valor, Status) VALUES (?, ?, ?, ?, ?, ?)",
                                                       (horario, ativo, 5, sentido, 5.0, '0'))
                                        conn.commit()
                                        print(f"Sinal processado e inserido: {sinal_formatado}")
                                    else:
                                        print(f"Sinal já existe no banco de dados: {sinal_formatado}")
                                else:
                                    print(f"Formato de hora inválido encontrado: {horario_str}")

                    elif " - " in linhas[i]:
                        # Formato simples com -
                        partes = linhas[i].split(" - ")
                        if len(partes) == 3:
                            ativo = partes[0].strip()
                            horario_str = partes[1].strip()
                            direcao = partes[2].strip()

                            print(f"Formato detectado: Ativo={ativo}, Hora={horario_str}, Direção={direcao}")

                            if ":" in horario_str:  # Verifica se horario_str possui o formato de hora esperado
                                horario = datetime.strptime(horario_str, "%H:%M").strftime("%H:%M")
                                sentido = direcao.upper()  # Certifique-se de que a direção está em maiúsculas

                                sinal_formatado = f"{horario} {ativo} 5 {sentido} 5.0"

                                # Verifica se o sinal já existe no banco de dados
                                cursor.execute("SELECT * FROM sinais WHERE Hora = ? AND Ativo = ? AND Direcao = ?", (horario, ativo, sentido))
                                data = cursor.fetchone()
                                if data is None:
                                    cursor.execute("INSERT INTO sinais (Hora, Ativo, Timer, Direcao, Valor, Status) VALUES (?, ?, ?, ?, ?, ?)",
                                                   (horario, ativo, 5, sentido, 5.0, '0'))
                                    conn.commit()
                                    print(f"Sinal processado e inserido: {sinal_formatado}")
                                else:
                                    print(f"Sinal já existe no banco de dados: {sinal_formatado}")
                            else:
                                print(f"Formato de hora inválido encontrado: {horario_str}")

                    i += 1

            conn.close()

        except Exception as e:
            print(f"Erro ao processar mensagem: {e}")

    print("Aguardando novas mensagens...")

    try:
        await client.run_until_disconnected()
    except (KeyboardInterrupt, SystemExit):
        print("Script interrompido.")
    except Exception as e:
        print(f"Ocorreu um erro inesperado: {e}")
    finally:
        # Feche a conexão com o banco de dados ao final do script
        conn.close()

if __name__ == '__main__':
    asyncio.run(main())
