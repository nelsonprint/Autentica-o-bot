import sqlite3

def excluir_dados():
    # Conectar ao banco de dados SQLite
    conn = sqlite3.connect('ordens.db')
    cursor = conn.cursor()
    
    try:
        # Pergunta ao usuário se deseja excluir todos os dados
        resposta = input("Deseja excluir todos os dados da tabela 'sinais'? (s/n): ").strip().lower()
        if resposta == 's':
            # Exclui todos os dados da tabela 'sinais'
            cursor.execute("DELETE FROM sinais")
            conn.commit()
            print("Todos os dados foram excluídos com sucesso.")
        else:
            print("Operação cancelada. Nenhum dado foi excluído.")
    except Exception as e:
        print(f"Ocorreu um erro: {e}")
    finally:
        # Fechar a conexão com o banco de dados
        conn.close()

if __name__ == '__main__':
    excluir_dados()
