import sqlite3
import schedule
import time

# Função para conectar ao banco de dados
def conectar_banco():
    conn = sqlite3.connect('ordens.db')
    return conn, conn.cursor()

# Função para fechar a conexão com o banco de dados
def fechar_conexao(conn):
    conn.close()

# Função para deletar registros na tabela 'sinais' onde o status é 'x'
def deletar_ordens_com_status_x():
    conn, cursor = conectar_banco()
    try:
        cursor.execute("DELETE FROM sinais WHERE Status = 'x'")
        conn.commit()  # Commit para aplicar a deleção ao banco de dados
        print("Registros com Status 'x' foram deletados.")
    except sqlite3.Error as e:
        print(f"Erro ao deletar dados: {e}")
    finally:
        fechar_conexao(conn)

# Função para ler e exibir as ordens da tabela 'sinais'
def ler_ordens():
    conn, cursor = conectar_banco()
    try:
        cursor.execute("SELECT * FROM sinais")
        ordens = cursor.fetchall()

        if not ordens:
            print("Não há ordens cadastradas.")
        else:
            print("Ordens cadastradas:")
            for ordem in ordens:
                print(f"Hora: {ordem[0]}, Ativo: {ordem[1]}, Timer: {ordem[2]}, Direcao: {ordem[3]}, Valor: {ordem[4]}, Status: {ordem[5]}")

    except sqlite3.Error as e:
        print(f"Erro ao ler dados: {e}")
    finally:
        fechar_conexao(conn)

# Função principal
def main():
    # Agendar a tarefa para deletar ordens com status 'x' a cada 5 minutos
    schedule.every(5).minutes.do(deletar_ordens_com_status_x)

    while True:
        schedule.run_pending()  # Executa as tarefas agendadas que estão pendentes
        time.sleep(1)  # Espera por 1 segundo antes de verificar novamente

if __name__ == '__main__':
    main()
