import sqlite3

# Função para conectar ao banco de dados
def conectar_banco():
    conn = sqlite3.connect('ordens.db')
    return conn, conn.cursor()

# Função para fechar a conexão com o banco de dados
def fechar_conexao(conn):
    conn.close()
# Função para atualizar um registro na tabela 'sinais'
def atualizar_registro(conn, cursor, linha_atualizar, coluna, novo_valor):
    try:
        # Execute a atualização na tabela 'sinais'
        cursor.execute(f"UPDATE sinais SET {coluna} = ? WHERE rowid = ?", (novo_valor, linha_atualizar))
        conn.commit()  # Commit para aplicar a atualização ao banco de dados

        # Verifique se algum registro foi atualizado
        if cursor.rowcount > 0:
            print(f"Atualização bem-sucedida para a linha {linha_atualizar}. Nova coluna '{coluna}': {novo_valor}")
        else:
            print(f"Nenhum registro encontrado para atualização com a linha {linha_atualizar}.")

    except sqlite3.Error as e:
        print(f"Erro ao atualizar dados: {e}")

# Função principal
def main():
    conn, cursor = conectar_banco()

    try:
        while True:
            # Exiba as linhas existentes para o usuário escolher qual deseja alterar
            cursor.execute("SELECT rowid, * FROM sinais")
            registros = cursor.fetchall()

            print("Registros disponíveis para atualização:")
            for row in registros:
                print(f"{row[0]} - Hora: {row[1]}, Ativo: {row[2]}, Timer: {row[3]}, Direcao: {row[4]}, Valor: {row[5]}, Status: {row[6]}")

            # Solicite ao usuário que escolha qual linha deseja atualizar
            linha_atualizar = int(input("\nDigite o número da linha que deseja atualizar: "))

            # Verifique se a linha escolhida existe
            cursor.execute("SELECT rowid FROM sinais WHERE rowid = ?", (linha_atualizar,))
            if cursor.fetchone() is None:
                print(f"A linha {linha_atualizar} não existe na tabela.")
                continue

            # Solicite ao usuário que escolha qual coluna deseja atualizar
            colunas = ["Hora", "Ativo", "Timer", "Direcao", "Valor", "Status"]
            print("\nColunas disponíveis para atualização:")
            for i, col in enumerate(colunas, 1):
                print(f"[{i}] {col}")

            coluna_escolhida = int(input("Digite o número da coluna que deseja atualizar: ")) - 1

            if coluna_escolhida < 0 or coluna_escolhida >= len(colunas):
                print("Número da coluna inválido.")
                continue

            coluna = colunas[coluna_escolhida]
            novo_valor = input(f"Digite o novo valor para '{coluna}': ")

            # Converta o valor para o tipo apropriado
            if coluna in ["Timer"]:
                novo_valor = int(novo_valor)
            elif coluna in ["Valor"]:
                novo_valor = float(novo_valor)

            # Chame a função para atualizar o registro no banco de dados
            atualizar_registro(conn, cursor, linha_atualizar, coluna, novo_valor)

            # Pergunte se o usuário deseja continuar ou finalizar
            continuar = input("Deseja fazer outra alteração? (s/n): ").lower()
            if continuar != 's':
                break

    finally:
        fechar_conexao(conn)

if __name__ == '__main__':
    main()
