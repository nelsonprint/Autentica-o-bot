from setuptools import setup, find_packages

setup(
    name='BOT DO MILHÃO',
    version='1.9.0',
    packages=find_packages(),
    install_requires=[
        'iqoptionapi',  # Adicione aqui outras dependências que seu projeto usa
    ],
    entry_points={
        'console_scripts': [
            'seu_comando=seu_pacote.seu_modulo:main',  # Ajuste conforme necessário
        ],
    },
)