import os
import datetime
import webbrowser
import tkinter as tk
from tkinter import messagebox
from cryptography.fernet import Fernet

# Caminhos dos arquivos para armazenar a chave secreta e a data de instalação criptografada
local_appdata_path = os.path.join(os.environ['LOCALAPPDATA'], 'secret1.key')
install_date_file = os.path.join(os.environ['LOCALAPPDATA'], 'install_date1.enc')

def generate_key():
    if not os.path.exists(local_appdata_path):
        key = Fernet.generate_key()
        with open(local_appdata_path, 'wb') as key_file:
            key_file.write(key)
        print(f"Computador registrado")
    else:
        print(f"Este Sistema já foi utilizado por 5 dias.")

def generate_install_date():
    if not os.path.exists(install_date_file):
        install_date = datetime.datetime.now()
        encrypted_date = encrypt_data(install_date.strftime('%Y-%m-%d'))
        with open(install_date_file, 'wb') as file:
            file.write(encrypted_date)
        print(f"Data de instalação gerada e salva em '{install_date_file}'.")
    else:
        print(f"....")

def encrypt_data(data):
    key = load_key()
    f = Fernet(key)
    encrypted_data = f.encrypt(data.encode())
    return encrypted_data

def load_key():
    return open(local_appdata_path, 'rb').read()

def decrypt_data(encrypted_data):
    key = load_key()
    f = Fernet(key)
    decrypted_data = f.decrypt(encrypted_data).decode()
    return decrypted_data

def get_install_date():
    if os.path.exists(install_date_file):
        with open(install_date_file, 'rb') as file:
            encrypted_date = file.read()
            date_str = decrypt_data(encrypted_date)
            return datetime.datetime.strptime(date_str, '%Y-%m-%d')
    else:
        install_date = datetime.datetime.now()
        encrypted_date = encrypt_data(install_date.strftime('%Y-%m-%d'))
        with open(install_date_file, 'wb') as file:
            file.write(encrypted_date)
        return install_date

def check_expiration():
    install_date = get_install_date()
    current_date = datetime.datetime.now()
    days_used = (current_date - install_date).days

    if days_used >= 1:
        show_expiration_window()
        return False
    else:
        print(f"Período de avaliação: {days_used + 1} dias")
        return True

def show_expiration_window():
    window = tk.Tk()
    window.title("INSIDER Informa")
    
    # Mensagem completa
    message = (
        "Sistema já foi usado por 5 dias.\n Agora, adquira a sua assinatura"
    )
    
    # Cria uma label com a mensagem
    label = tk.Label(window, text=message, padx=20, pady=20, wraplength=300)
    label.pack()

    # Função para abrir o link no navegador
    def open_link():
        webbrowser.open("https://toplivre.online/venda-do-bot/")
    
    # Botão para abrir o link
    button = tk.Button(window, text="ADQUIRIR\n ASSINATURA\n AGORA", command=open_link, padx=10, pady=5)
    button.pack(pady=10)

    # Centraliza a janela na tela
    window.update_idletasks()  # Atualiza as informações da janela
    window_width = window.winfo_width()
    window_height = window.winfo_height()
    screen_width = window.winfo_screenwidth()
    screen_height = window.winfo_screenheight()
    x = (screen_width // 2) - (window_width // 2)
    y = (screen_height // 2) - (window_height // 2)
    window.geometry(f'{window_width}x{window_height}+{x}+{y}')

    window.mainloop()

def main():
    generate_key()
    generate_install_date()

    if not check_expiration():
        return

    print("Tecle enter para Entrar no Sistema.")
    input()  # Aguarda a entrada do usuário

    print("SISTEMA INICIADO. BOA SORTE")

if __name__ == "__main__":
    main()
