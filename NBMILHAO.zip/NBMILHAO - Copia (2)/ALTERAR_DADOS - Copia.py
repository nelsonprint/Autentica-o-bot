import sqlite3

# Função para conectar ao banco de dados
def conectar_banco():
    conn = sqlite3.connect('ordens.db')
    return conn, conn.cursor()

# Função para fechar a conexão com o banco de dados
def fechar_conexao(conn):
    conn.close()

# Função para atualizar um registro na tabela 'sinais'
def atualizar_registro(conn, cursor, linha_atualizar, novos_dados):
    try:
        # Execute a atualização na tabela 'sinais'
        cursor.execute("UPDATE sinais SET Hora = ?, Ativo = ?, Timer = ?, Direcao = ?, Valor = ?, Status = ? WHERE rowid = ?",
                       (novos_dados['Hora'], novos_dados['Ativo'], novos_dados['Timer'], novos_dados['Direcao'], novos_dados['Valor'], novos_dados['Status'], linha_atualizar))
        conn.commit()  # Commit para aplicar a atualização ao banco de dados

        # Verifique se algum registro foi atualizado
        if cursor.rowcount > 0:
            print(f"Atualização bem-sucedida para a linha {linha_atualizar}. Novos dados:")
            print(f"Hora: {novos_dados['Hora']}, Ativo: {novos_dados['Ativo']}, Timer: {novos_dados['Timer']}, Direcao: {novos_dados['Direcao']}, Valor: {novos_dados['Valor']}, Status: {novos_dados['Status']}")
        else:
            print(f"Nenhum registro encontrado para atualização com a linha {linha_atualizar}.")

    except sqlite3.Error as e:
        print(f"Erro ao atualizar dados: {e}")

# Função principal
def main():
    conn, cursor = conectar_banco()

    try:
        # Exiba as linhas existentes para o usuário escolher qual deseja alterar
        cursor.execute("SELECT rowid, * FROM sinais")
        registros = cursor.fetchall()

        print("Registros disponíveis para atualização:")
        for row in registros:
            print(f"{row[0]} - Hora: {row[1]}, Ativo: {row[2]}, Timer: {row[3]}, Direcao: {row[4]}, Valor: {row[5]}, Status: {row[6]}")

        # Solicite ao usuário que escolha qual linha deseja atualizar
        linha_atualizar = int(input("\nDigite o número da linha que deseja atualizar: "))

        # Verifique se a linha escolhida existe
        cursor.execute("SELECT rowid FROM sinais WHERE rowid = ?", (linha_atualizar,))
        if cursor.fetchone() is None:
            print(f"A linha {linha_atualizar} não existe na tabela.")
            return

        # Solicite ao usuário os novos dados no formato desejado
        novo_dado = input(f"Digite os novos dados no formato 'Hora, Ativo, Timer, Direcao, Valor, Status' para a linha {linha_atualizar}: ")
        novo_dado_lista = novo_dado.split(', ')

        if len(novo_dado_lista) != 6:
            print("Formato de entrada inválido. Certifique-se de inserir os dados no formato correto.")
            return

        novos_dados = {
            'Hora': novo_dado_lista[0],
            'Ativo': novo_dado_lista[1],
            'Timer': int(novo_dado_lista[2]),
            'Direcao': novo_dado_lista[3],
            'Valor': float(novo_dado_lista[4]),
            'Status': novo_dado_lista[5]
        }

        # Chame a função para atualizar o registro no banco de dados
        atualizar_registro(conn, cursor, linha_atualizar, novos_dados)

    finally:
        fechar_conexao(conn)

if __name__ == '__main__':
    main()
