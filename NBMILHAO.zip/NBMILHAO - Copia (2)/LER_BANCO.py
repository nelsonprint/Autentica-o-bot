import sqlite3
import time

# Função para conectar ao banco de dados
def conectar_banco():
    conn = sqlite3.connect('ordens.db')
    return conn, conn.cursor()

# Função para fechar a conexão com o banco de dados
def fechar_conexao(conn):
    conn.close()

# Função para ler e exibir as ordens da tabela 'sinais'
def ler_ordens():
    conn, cursor = conectar_banco()
    try:
        cursor.execute("SELECT * FROM sinais")
        ordens = cursor.fetchall()

        if not ordens:
            print("Não há ordens cadastradas.")
        else:
            print("Ordens cadastradas:")
            for ordem in ordens:
                print(f"Hora: {ordem[0]}, Ativo: {ordem[1]}, Timer: {ordem[2]}, Direcao: {ordem[3]}, Valor: {ordem[4]}, Status: {ordem[5]}")

    except sqlite3.Error as e:
        print(f"Erro ao ler dados: {e}")
    finally:
        fechar_conexao(conn)

# Função principal
def main():
    while True:
        ler_ordens()
        time.sleep(5)  # Pausa a execução por 5 segundos

if __name__ == '__main__':
    main()
