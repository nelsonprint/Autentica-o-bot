"""Module for IQ Option API websocket received."""
