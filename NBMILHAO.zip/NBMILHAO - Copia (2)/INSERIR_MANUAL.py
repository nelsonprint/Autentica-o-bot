import sqlite3

# Conectar ao banco de dados
conn = sqlite3.connect('ordens.db')
cursor = conn.cursor()

# Definir a função para adicionar uma entrada na tabela sinais
def adicionar_entrada(hora, ativo, timer, direcao, valor):
    query = "INSERT INTO sinais (Hora, Ativo, Timer, Direcao, Valor) VALUES (?, ?, ?, ?, ?)"
    dados = (hora.strip(), ativo.strip(), timer, direcao.strip(), valor)
    cursor.execute(query, dados)
    conn.commit()

while True:
    # Solicitar dados ao usuário
    entrada = input("Digite os dados no formato 'HH:MM,Ativo,Timer,Direcao,Valor' (ex: '00:00,EURUSD,1,PUT,5'): ")

    # Dividir a entrada em partes
    try:
        hora, ativo, timer, direcao, valor = entrada.split(',')
        timer = int(timer)
        valor = float(valor)

        # Adicionar entrada
        adicionar_entrada(hora, ativo, timer, direcao, valor)
        print("Entrada adicionada com sucesso.")
    except ValueError:
        print("Erro: Certifique-se de que todos os valores estão no formato correto e separados por vírgula.")

    # Perguntar se deseja adicionar outro registro
    continuar = input("Deseja adicionar outro registro? (s/n): ").strip().lower()
    if continuar != 's':
        break

# Fechar conexão
conn.close()
print("Conexão com o banco de dados encerrada.")
